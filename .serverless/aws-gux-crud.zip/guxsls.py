import sys

for param in sys.argv:
    print(param)